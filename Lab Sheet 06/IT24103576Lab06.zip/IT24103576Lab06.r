setwd("C:\\Users\\USER\\OneDrive\\Desktop\\IT24103576")
##Question 1
#Part 1
#Binomial Distribution
#Here, random variable X has binomial distribution with n=47 and p=0.85

dbinom(47,50,0.85)

##Question 02
#Part 1
# A call center receives an average of 12 customer calls per hour

#Part 2
#Poisson distribution
#Here, random variable X has poisson distribution with lambda=12

dpois(15,12)

